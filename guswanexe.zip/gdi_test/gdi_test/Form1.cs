﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using System.Media;
using System.Diagnostics;

namespace gdi_test
{
    public partial class gdi : Form
    {
        [DllImport("user32.dll")]
        static extern IntPtr GetDesktopWindow();

        [DllImport("user32.dll")]
        static extern IntPtr GetWindowDC(IntPtr hWnd);

        [DllImport("Shell32.dll", EntryPoint = "ExtractIconExW", CharSet = CharSet.Unicode, ExactSpelling = true,
        CallingConvention = CallingConvention.StdCall)]
        private static extern int ExtractIconEx(string sFile, int iIndex, out IntPtr piLargeVersion,
        out IntPtr piSmallVersion, int amountIcons);

        [DllImport("user32.dll")]
        static extern bool InvalidateRect(IntPtr hWnd, IntPtr lpRect, bool bErase);

        [DllImport("gdi32.dll")]
        static extern bool StretchBlt(IntPtr hdcDest, int nXOriginDest, int nYOriginDest, int nWidthDest,
        int nHeightDest, IntPtr hdcSrc, int nXOriginSrc, int nYOriginSrc, int nWidthSrc, int nHeightSrc,
        TernaryRasterOperations dwRop);

        public enum TernaryRasterOperations
        {
            SRCCOPY = 0x00CC0020,
            SRCPAINT = 0x00EE0086,
            SRCAND = 0x008800C6,
            SRCINVERT = 0x00660046,
            SRCERASE = 0x00440328,
            NOTSRCCOPY = 0x00330008,
            NOTSRCERASE = 0x001100A6,
            MERGECOPY = 0x00C000CA,
            MERGEPAINT = 0x00BB0226,
            PATCOPY = 0x00F00021,
            PATPAINT = 0x00FB0A09,
            PATINVERT = 0x005A0049,
            DSTINVERT = 0x00550009,
            BLACKNESS = 0x00000042,
            WHITENESS = 0x00FF0062,
        }

        public static Icon Extract(string file, int number, bool largeIcon)
        {
            IntPtr large;
            IntPtr small;
            ExtractIconEx(file, number, out large, out small, 1);
            try
            {
                return Icon.FromHandle(largeIcon ? large : small);
            }
            catch
            {
                return null;
            }
        }

        public gdi()
        {
            InitializeComponent();
            TransparencyKey = BackColor;
        }

        private void gdi_Load(object sender, EventArgs e)
        {
            timer1.Start();
            timer2.Start();
            timer3.Start();
            timer4.Start();
            timer5.Start();
            timer6.Start();
            timer7.Start();
            timer8.Start(); // Browser + YouAreIdiot SFX
        }

        Random r;

        // ===== Efek desktop glitch =====
        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            r = new Random();
            IntPtr hwnd = GetDesktopWindow();
            IntPtr hdc = GetWindowDC(hwnd);
            int x = Screen.PrimaryScreen.Bounds.Width;
            int y = Screen.PrimaryScreen.Bounds.Height;

            if (timer1.Interval > 101)
                timer1.Interval -= 100;
            else if (timer1.Interval > 51)
                timer1.Interval -= 10;
            else
                timer1.Interval = 10;

            StretchBlt(hdc, r.Next(10), r.Next(10), x - r.Next(25), y - r.Next(25), hdc, 0, 0, x, y, TernaryRasterOperations.SRCCOPY);
            StretchBlt(hdc, x, 0, -x, y, hdc, 0, 0, x, y, TernaryRasterOperations.SRCCOPY);
            StretchBlt(hdc, 0, y, x, -y, hdc, 0, 0, x, y, TernaryRasterOperations.SRCCOPY);

            timer1.Start();
        }

        Icon icon = Extract("shell32.dll", 235, true);

        // ===== Cursor icon =====
        private void timer2_Tick(object sender, EventArgs e)
        {
            timer2.Stop();
            this.Cursor = new Cursor(Cursor.Current.Handle);
            int posX = Cursor.Position.X;
            int posY = Cursor.Position.Y;

            IntPtr desktop = GetWindowDC(IntPtr.Zero);
            using (Graphics g = Graphics.FromHdc(desktop))
            {
                g.DrawIcon(icon, posX, posY);
            }
            timer2.Start();
        }

        // ===== NOTSRCCOPY effect =====
        private void timer3_Tick(object sender, EventArgs e)
        {
            timer3.Stop();
            r = new Random();
            IntPtr hwnd = GetDesktopWindow();
            IntPtr hdc = GetWindowDC(hwnd);
            int x = Screen.PrimaryScreen.Bounds.Width;
            int y = Screen.PrimaryScreen.Bounds.Height;
            StretchBlt(hdc, 0, 0, x, y, hdc, 0, 0, x, y, TernaryRasterOperations.NOTSRCCOPY);
            timer3.Interval = r.Next(5000);
            timer3.Start();
        }

        private void timer4_Tick(object sender, EventArgs e)
        {
            timer4.Stop();
            r = new Random();
            IntPtr hwnd = GetDesktopWindow();
            IntPtr hdc = GetWindowDC(hwnd);
            int x = Screen.PrimaryScreen.Bounds.Width;
            int y = Screen.PrimaryScreen.Bounds.Height;
            StretchBlt(hdc, r.Next(x), r.Next(y), x = r.Next(500), y = r.Next(500), hdc, 0, 0, x, y, TernaryRasterOperations.NOTSRCCOPY);
            timer4.Interval = r.Next(1000);
            timer4.Start();
        }

        // ===== Efek suara random =====
        private void timer5_Tick(object sender, EventArgs e)
        {
            timer5.Stop();
            r = new Random();
            int sfx = r.Next(4);

            switch (sfx)
            {
                case 0: SystemSounds.Asterisk.Play(); break;
                case 1: SystemSounds.Beep.Play(); break;
                case 2: SystemSounds.Exclamation.Play(); break;
                case 3: SystemSounds.Hand.Play(); break;
            }

            timer5.Interval = r.Next(2000, 5000);
            timer5.Start();
        }

        // ===== Popup acak =====
        private void timer6_Tick(object sender, EventArgs e)
        {
            timer6.Stop();
            r = new Random();
            int act = r.Next(3);

            switch (act)
            {
                case 0: MessageBox.Show("Error: Something went wrong!", "Windows", MessageBoxButtons.OK, MessageBoxIcon.Error); break;
                case 1: Process.Start("cmd.exe"); break;
                case 2: Process.Start("https://www.google.com"); break;
            }

            timer6.Interval = r.Next(8000, 15000);
            timer6.Start();
        }

        // ===== Timer BSOD & Warning =====
        private void timer7_Tick(object sender, EventArgs e)
        {
            timer7.Stop();
            r = new Random();
            int act = r.Next(3);

            switch (act)
            {
                case 0: new BSODForm().ShowDialog(); break;
                case 1: new WarningForm("Warning 1: System instability detected!", "Warning").Show(); break;
                case 2: new WarningForm("Warning 2: Virus detected!", "Warning").Show(); break;
            }

            timer7.Interval = r.Next(10000, 20000);
            timer7.Start();
        }

        // ===== Timer Browser + "You are idiot" SFX =====
        private void timer8_Tick(object sender, EventArgs e)
        {
            timer8.Stop();
            r = new Random();
            int act = r.Next(5);

            switch (act)
            {
                case 0: new BSODForm().ShowDialog(); break;
                case 1: new WarningForm("Warning 1: System instability detected!", "Warning").Show(); break;
                case 2: new WarningForm("Warning 2: Virus detected!", "Warning").Show(); break;
                case 3: OpenRandomBrowser(); break;
                case 4: PlayYouAreIdiotSFX(); break;
            }

            timer8.Interval = r.Next(10000, 20000);
            timer8.Start();
        }

        private void PlayYouAreIdiotSFX()
        {
            try
            {
                using (SoundPlayer player = new SoundPlayer("you_are_idiot.wav"))
                {
                    player.Play();
                }
            }
            catch { }
        }

        private void OpenRandomBrowser()
        {
            try
            {
                Process.Start("https://www.google.com/search?q=you+are+idiot");
            }
            catch { }
        }
    }

    // ===== Form BSOD =====
    public class BSODForm : Form
    {
        public BSODForm()
        {
            this.FormBorderStyle = FormBorderStyle.None;
            this.WindowState = FormWindowState.Maximized;
            this.BackColor = Color.Blue;
            this.TopMost = true;

            Label lbl = new Label()
            {
                Text = "A problem has been detected and Windows has been shut down to prevent damage to your computer.\n\n" +
                       "If this is the first time you've seen this stop error screen, restart your computer.\n\n" +
                       "Technical information:\n*** STOP: 0x0000007B (0xFFFFFFFF, 0x00000000, 0x00000000, 0x00000000)",
                ForeColor = Color.White,
                Font = new Font("Consolas", 14),
                AutoSize = false,
                TextAlign = ContentAlignment.MiddleCenter,
                Dock = DockStyle.Fill
            };

            this.Controls.Add(lbl);
        }
    }

    // ===== Form Warning =====
    public class WarningForm : Form
    {
        public WarningForm(string message, string title)
        {
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.TopMost = true;
            this.Size = new Size(400, 150);

            Label lbl = new Label()
            {
                Text = message,
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Segoe UI", 10)
            };

            Button btn = new Button()
            {
                Text = "OK",
                Dock = DockStyle.Bottom
            };
            btn.Click += (s, e) => this.Close();

            this.Controls.Add(lbl);
            this.Controls.Add(btn);
            this.Text = title;
        }
    }
}
